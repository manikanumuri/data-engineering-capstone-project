const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Simulated Database
// Simulated Database
let storeData = [
    {
        rackId: 'R1',
        shelves: [
            { shelfName: 'A', items: [{ itemName: 'Product1', quantity: 4, price: 5 }, { itemName: 'Product2', quantity: 8, price: 8 }] },
            { shelfName: 'B', items: [{ itemName: 'Product3', quantity: 15, price: 12 }, { itemName: 'Product4', quantity: 5, price: 7 }] },
            { shelfName: 'C', items: [{ itemName: 'Product5', quantity: 20, price: 10 }, { itemName: 'Product6', quantity: 12, price: 15 }] },
        ],
    },
    {
        rackId: 'R2',
        shelves: [
            { shelfName: 'A', items: [{ itemName: 'Product7', quantity: 8, price: 6 }, { itemName: 'Product8', quantity: 10, price: 9 }] },
            { shelfName: 'B', items: [{ itemName: 'Product9', quantity: 0, price: 11 }, { itemName: 'Product10', quantity: 15, price: 8 }] },
            { shelfName: 'C', items: [{ itemName: 'Product11', quantity: 12, price: 7 }, { itemName: 'Product12', quantity: 18, price: 12 }] },
        ],
    },
    {
        rackId: 'R3',
        shelves: [
            { shelfName: 'A', items: [{ itemName: 'Product13', quantity: 14, price: 10 }, { itemName: 'Product14', quantity: 9, price: 14 }] },
            { shelfName: 'B', items: [{ itemName: 'Product15', quantity: 7, price: 6 }, { itemName: 'Product16', quantity: 11, price: 13 }] },
            { shelfName: 'C', items: [{ itemName: 'Product17', quantity: 10, price: 9 }, { itemName: 'Product18', quantity: 15, price: 11 }] },
        ],
    },
    {
        rackId: 'R4',
        shelves: [
            { shelfName: 'A', items: [{ itemName: 'Product19', quantity: 20, price: 8 }, { itemName: 'Product20', quantity: 15, price: 10 }] },
            { shelfName: 'B', items: [{ itemName: 'Product21', quantity: 12, price: 11 }, { itemName: 'Product22', quantity: 9, price: 7 }] },
            { shelfName: 'C', items: [{ itemName: 'Product23', quantity: 18, price: 13 }, { itemName: 'Product24', quantity: 10, price: 6 }] },
        ],
    },
];


// API Routes

// Get store structure
app.get('/store_structure', (req, res) => {
    const storeStructure = storeData.map(rack => ({
        rackId: rack.rackId,
        shelves: rack.shelves.map(shelf => ({
            shelfName: shelf.shelfName,
            items: shelf.items,
        })),
    }));
    res.json({ storeStructure });
});

// Get shelf data
app.get('/shelf_data/:rackId/:shelfName', (req, res) => {
    const { rackId, shelfName } = req.params;
    const rack = storeData.find(rack => rack.rackId === rackId);

    if (rack) {
        const shelf = rack.shelves.find(shelf => shelf.shelfName === shelfName);
        if (shelf) {
            res.json({ rackId, shelf });
        } else {
            res.status(404).json({ message: 'Shelf not found' });
        }
    } else {
        res.status(404).json({ message: 'Rack not found' });
    }
});

// Update shelf data
app.put('/shelf_data/:rackId/:shelfName', (req, res) => {
    const { rackId, shelfName } = req.params;
    const rack = storeData.find(rack => rack.rackId === rackId);

    if (rack) {
        const shelf = rack.shelves.find(shelf => shelf.shelfName === shelfName);
        if (shelf) {
            shelf.items = req.body.items;
            res.json({ message: 'Shelf data updated successfully' });
        } else {
            res.status(404).json({ message: 'Shelf not found' });
        }
    } else {
        res.status(404).json({ message: 'Rack not found' });
    }
});

app.put('/shelf_item/:rackId/:shelfName/:itemName', (req, res) => {
    const { rackId, shelfName, itemName } = req.params;
    const rack = storeData.find(rack => rack.rackId === rackId);

    if (rack) {
        const shelf = rack.shelves.find(shelf => shelf.shelfName === shelfName);
        if (shelf) {
            const itemIndex = shelf.items.findIndex(item => item.itemName === itemName);
            if (itemIndex !== -1) {
                shelf.items[itemIndex] = req.body.updateItem;
                res.json({ message: 'Item updated successfully' });
            } else {
                res.status(404).json({ message: 'Item not found on the shelf' });
            }
        } else {
            res.status(404).json({ message: 'Shelf not found' });
        }
    } else {
        res.status(404).json({ message: 'Rack not found' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
